package com.example.homework_api_sqflite;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
